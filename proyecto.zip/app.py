from flask import Flask, render_template, redirect
import paho.mqtt.client as mqtt
import threading
from datetime import datetime
import requests

app = Flask(__name__)

BROKER = "54.36.178.49"
PUERTO = 1883

TOPIC_CONTROL = "bastian/control/acceso"
TOPIC_MONITOR = "bastian/monitor/flask"

SUPABASE_URL = "https://tidqktzpihoriskbjkve.supabase.co/rest/v1/registro_eventos"
SUPABASE_KEY = "sb_publishable_p8j8NjRxc2n5Y1QYsDGNQg_jopdAWXl"

mensajes = []
mqtt_client = mqtt.Client()

def agregar_mensaje(texto):
    hora = datetime.now().strftime("%H:%M:%S")
    mensajes.insert(0, f"[{hora}] {texto}")
    if len(mensajes) > 50:
        mensajes.pop()

def registrar_supabase(estado):
    datos = {
        "estado": estado,
        "dispositivo": "ESP32_A",
        "origen": "Flask"
    }

    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": "Bearer " + SUPABASE_KEY,
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
    }

    try:
        r = requests.post(SUPABASE_URL, json=datos, headers=headers, timeout=8)
        if r.status_code in [200, 201, 204]:
            agregar_mensaje("Evento registrado en Supabase: " + estado)
        else:
            agregar_mensaje("Error Supabase: " + str(r.status_code))
            print("Error Supabase:", r.status_code, r.text)
    except Exception as e:
        agregar_mensaje("Error conectando a Supabase")
        print("Error conectando a Supabase:", e)

def on_connect(client, userdata, flags, rc):
    print("Conectado al broker:", rc)
    client.subscribe(TOPIC_MONITOR)
    agregar_mensaje("Flask conectado al broker MQTT")

def on_message(client, userdata, msg):
    texto = msg.payload.decode()

    if "conectado como supervisor" in texto:
        return

    print("Mensaje:", texto)
    agregar_mensaje(texto)

mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

def conectar_mqtt():
    mqtt_client.connect(BROKER, PUERTO, 60)
    mqtt_client.loop_forever()

threading.Thread(target=conectar_mqtt, daemon=True).start()

@app.route("/")
def index():
    return render_template("index.html", mensajes=mensajes)

@app.route("/enviar/<color>")
def enviar(color):
    mqtt_client.publish(TOPIC_CONTROL, color)
    agregar_mensaje("Flask envió orden: " + color)
    registrar_supabase(color)
    return redirect("/")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
